let h1Text = document.querySelector("#h1Text")
let InputNumb = document.querySelector("#InputNumb")
let InputNumb2 = document.querySelector("#InputNumb2")
let BtSoma = document.querySelector("#BtSoma")

function Somar() {
    let Numb = Number(InputNumb.value);
    let Numb2 = Number(InputNumb2.value);
    let soma = Numb + Numb2;
    h1Text.textContent = soma;

}

BtSoma.onclick = Somar;

