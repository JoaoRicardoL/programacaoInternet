function reajuste() {
    let Inp = Number(document.getElementById("Inp").value)
    let resultado = Inp * 0.01
    document.getElementById("resultado").textContent = Number(Inp + resultado)
}