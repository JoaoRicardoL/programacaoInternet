function ValQuant() {
    let ValKilo = Number(document.getElementById("ValKilo").value)
    let QuantKilo = Number(document.getElementById("QuantKilo").value)
    let resultado = ValKilo * QuantKilo;
    document.getElementById("resultado").textContent = resultado;
}