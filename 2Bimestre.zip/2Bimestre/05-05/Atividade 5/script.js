function MorM() {
    let a = Number(document.getElementById("Inp1"))
    let b = Number(document.getElementById("Inp2"))

    if (a < b) {
        return `${a}`
    } else if (b > a) {
        return `${b}`
    }

}

MorM();