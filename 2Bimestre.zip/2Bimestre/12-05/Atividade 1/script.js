let dolarAtual = 5.00;

let aumento1 = (dolarAtual * 1.01)
let aumento2 = (dolarAtual * 1.02)
let aumento5 = (dolarAtual * 1.05)
let aumento10 = (dolarAtual * 1.10)

