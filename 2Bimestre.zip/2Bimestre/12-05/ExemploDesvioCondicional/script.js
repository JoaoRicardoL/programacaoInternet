let h3Resultado = document.getElementById("h3Resultado");

function calcularMedia() {
    let nota1Bim = Number(document.getElementById("nota1Bim").value);
    let nota2Bim = Number(document.getElementById("nota2Bim").value);
    let media = (nota1Bim + nota2Bim) / 2;

    if (media >= 60) {
        h3Resultado.textContent = "O aluno esta APROVADO"
    } else {
        h3Resultado.textContent = "O aluno esta REPROVADO"
    }
}