let InpNumb1 = document.querySelector("#InpNumb1")
let InpNumb2 = document.querySelector("#InpNumb2")

function CalcularTroco() {
    let Numb1 = Number(InpNumb1.value);
    let Numb2 = Number(InpNumb2.value);
    let troco = Numb1 - Numb2;
    document.getElementById("resultado").textContent = troco;
}