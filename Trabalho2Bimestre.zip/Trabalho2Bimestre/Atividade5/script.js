function CalcularSaldo() {
    let saldo = Number(document.getElementById("saldo").value);
    let resultado = "";

    if (saldo >= 0 && saldo <= 200) {
        resultado = saldo * 1
    } else if (saldo >= 201 && saldo <= 400) {
        resultado = saldo * 1.20
    } else if (saldo >= 401 && saldo <= 600) {
        resultado = saldo * 1.30
    } else if (saldo >= 600) {
        resultado = saldo * 1.40
    } else {
        resultado = String("Erro")
    }
    document.getElementById("h3txt").innerText = resultado.toFixed(2)
}