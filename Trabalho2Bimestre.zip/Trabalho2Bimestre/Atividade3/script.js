function CalcularImposto() {
    let valorCarro = Number(document.getElementById("inp1").value);
    let ano = Number(document.getElementById("inp2").value);
    let resultado = "";

    if (ano < 1990) {
        resultado = (valorCarro * 0.01) 
    } else {
        resultado = (valorCarro * 0.015)
    }

    document.getElementById("h3txt").textContent = `O valor do Imposto é R$ ${resultado}`
}
