function CalcularPreco() {
    let preco = Number(document.getElementById("preco").value);
    let pagamento = document.getElementById("pagamento").value;
    let resultado = "";

    if (pagamento == "VistaCheque") {
        resultado = preco * 0.90
    } else if (pagamento == "VistaCartao") {
        resultado = preco * 0.85
    } else if (pagamento == "Dvezes") {
        resultado = preco / 2
    } else if (pagamento == "DJuro") {
        resultado = (preco * 1.10) / 2
    } else {
        resultado = String("Erro")
    }
    

    

    document.getElementById("h3txt").innerHTML = `R$ ${resultado.toFixed(2)}`
}
