function CalcularPagamento() {
    let qtdAula = Number(document.getElementById("qtdAula").value);
    let professor = document.getElementById("professor").value;
    let sal = "";

    if (professor == "N1") {
        sal = 12.00 * qtdAula * 4.5
    } else if (professor == "N2") {
        sal = 17.00 * qtdAula * 4.5
    } else if (professor == "N3") {
        sal = 25.00 * qtdAula * 4.5
    } else {
        sal = String("Erro")
    }

    document.getElementById("h3txt").innerText = `R$ ${sal.toFixed(2)}`
}