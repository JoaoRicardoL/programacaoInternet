function VerTriangulo() {
    let x = Number(document.getElementById("inp1").value);
    let y = Number(document.getElementById("inp2").value);
    let z = Number(document.getElementById("inp3").value);
    let resultado = "";

   if (x < y + z && y < x + z && z < x + y) {
    if (x == y && y == z) {
        resultado = "Triangulo Equilatero"
    } else if (x == y || y == z || x == z) {
        resultado = "Triangulo Isosceles"
    } else {
        resultado = "Triangulo Escaleno"
    }
   } else {
    resultado = "Não é um triangulo"
   }

   document.getElementById("h2Txt").textContent = resultado;
}