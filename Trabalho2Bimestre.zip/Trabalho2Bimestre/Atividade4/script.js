function CalcularSalario() {
    let cargo = document.getElementById("cargo").value;
    let salario = Number(document.getElementById("salario").value);
    let resultado = "";

    if (cargo == "gerente") {
         resultado = salario * 1.10
    } else if (cargo == "engenheiro") {
         resultado = salario * 1.20
    } else if (cargo == "tecnico") {
         resultado = salario * 1.30
    } else if (cargo == "nenhum") {
         resultado = salario * 1.40
    } else {
        resultado = String("Erro")
    }
    
    document.getElementById("h3txt").innerText = `Salário antigo: R$ ${salario} Salário novo: R$ ${resultado}`
}