function CalcularPedido() {
    let quantidade = Number(document.getElementById("quantidade").value);
    let cardapio = document.getElementById("cardapio").value
    let resultado = "";

    if (cardapio == "cachorro") {
        resultado = 11.00 * quantidade
    } else if (cardapio == "bauru") {
        resultado = 8.50 * quantidade
    } else if (cardapio == "misto") {
        resultado = 8.00 * quantidade
    } else if (cardapio == "burger") {
        resultado = 9.00 * quantidade
    } else if (cardapio == "chees") {
        resultado = 10.00 * quantidade
    } else if (cardapio == "refri") {
        resultado = 4.50 * quantidade
    } else {
        resultado = String("Erro")
    }

    document.getElementById("h3txt").innerText = `Valor Final do seu pedido: R$ ${resultado.toFixed(2)}`
}